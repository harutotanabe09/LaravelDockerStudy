<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="UTF-8">
  <title>My First Page</title>
</head>
<body>
  <h2>Hello World!!</h2>
  <p>皆さん、こんにちは</p>
Jun/04/2018<p />
</body>
</html>